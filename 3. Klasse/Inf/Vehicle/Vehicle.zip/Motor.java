package Valentin.Adlgasser;

/**
 * This class adds horsepower to a vehicle
 */
public class Motor {
    private int horsepower;

    public int getHorsepower() {
        return horsepower;
    }

    public void setHorsepower(int horsepower) {
        this.horsepower = horsepower;
    }
}
