<!--
    register.php
    Author: Valentin Adlgasser
    Date: 03.06.2020
    Version: 1.1
-->

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link href=".\resources\images\icon.png" rel="icon"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <link href=".\resources\styles\main.css" rel="stylesheet" type="text/css">
    <link href=".\resources\styles\register.css" rel="stylesheet" type="text/css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
<div class="wrapper">
    <div class="content">
        <nav>
            <ul class="navUl">
                <li>
                    <a href="index.php">
                        <div class="icon">
                            <i class="fa fa-home" aria-hidden="true"></i>
                            <i class="fa fa-home" aria-hidden="true"></i>
                        </div>
                        <div class="name" data-test="Home"><b>Home</b></div>
                    </a>
                </li>
                <li>
                    <a href=".\register.php">
                        <div class="icon">
                            <i class="fa fa-registered" aria-hidden="true"></i>
                            <i class="fa fa-registered" aria-hidden="true"></i>
                        </div>
                        <div class="name" data-test="Register"><b>Register</b></div>
                    </a>
                </li>
                <li>
                    <a href=".\logout.php">
                        <div class="icon">
                            <i class="fa fa-sign-out" aria-hidden="true"></i>
                            <i class="fa fa-sign-out" aria-hidden="true"></i>
                        </div>
                        <div class="name" data-test="Logout"><b>Logout</b></div>
                    </a>
                </li>
            </ul>
        </nav>
        <form id="Register" action=".\resources\scripts\registerToCSV.php" method="post" enctype="multipart/form-data">
            <div ID="Konto">
                <label>Title:</label><br>
                <fieldset style="border:none">
                    <label for="mr">Mr.</label>
                    <input type="radio" id="mr" name="title" value="Mr."><br>
                    <label for="ms">Ms.</label>
                    <input type="radio" id="ms" name="title" value="Ms."><br>
                </fieldset>
                <label for="firstName">First Name:</label>
                <input type="text" id="firstName" name="firstName" placeholder="Enter your first name" autofocus="1"><br>
                <label for="lastName">Last Name:</label>
                <input type="text" id="lastName" name="lastName" placeholder="Enter your last name"><br>
                <label for="birthday">Birthday:</label>
                <input type="date" id="birthday" name="birthday" placeholder="Enter your birthday"><br>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Enter your Email"><br>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" placeholder="Enter your Password"><br>
                <label for="repeatPassword">Repeat Password:</label>
                <input type="password" id="repeatPassword" name="repeatPassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" placeholder="Repeat your Password"><br>
            </div><br>

            <div ID="address">
                <label for="street">Street:</label>
                <input type="text" id="street" name="street" placeholder="Enter your street"><br>
                <label for="city">City:</label>
                <input type="text" id="city" name="city" placeholder="Enter your city"><br>
                <label for="zipCode">Zip Code:</label>
                <input type="number" id="zipCode" name="zipCode" placeholder="Enter your Zip Code" pattern="[0-9]{4}"><br>
                <label for="province">Province:</label>
                <select id="province" name="province">
                    <option value="Burgenland">Burgenland</option>
                    <option value="Kärnten">Kärnten</option>
                    <option value="Niederösterreich">Niederösterreich</option>
                    <option value="Oberösterreich">Oberösterreich</option>
                    <option value="Salzburg">Salzburg</option>
                    <option value="Steiermark">Steiermark</option>
                    <option value="Tirol">Tirol</option>
                    <option value="Vorarlberg">Vorarlberg</option>
                    <option value="Wien">Wien</option>
                </select><br>
                <label for="telephone">Telephone:</label>
                <input type="tel" id="telephone" name="telephone" placeholder="Enter your telephone number">
            </div><br>

            <div ID="upload">
                <label for="uploadFile">Upload a file:</label>
                <input type="file" name="uploadFile">
            </div><br>

            <input type="submit" value="Submit" name="submit">
            <input type="reset" value="Reset">

        </form>
    </div>
</div>

<footer class="footer">
    Made by Valentin Adlgasser
</footer>

</body>
</html>