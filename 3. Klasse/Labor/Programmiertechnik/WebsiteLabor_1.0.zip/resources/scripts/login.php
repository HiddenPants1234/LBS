<?php
session_start();

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if(!strlen($email) || !strlen($password)){
        die('Please enter email and password!');
    }

    $success = false;

    $handle = fopen('..\..\UserCSV\EmailAndPassword.csv', 'r');

    while (($data = fgetcsv($handle)) !== FALSE){
        if($data[0] == $email && password_verify($password, $data[1])){
            $success = true;
            break;
        }
    }

    fclose($handle);

    if($success){
        $_SESSION['user_id'] = $email;
        header('Location: ..\..\logout.php');
    }
    else{
        echo "Not working";
    }
