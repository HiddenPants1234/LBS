<?php

session_start();

if(isset($_SESSION['user_id'])){
?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Logout</title>
        <link href=".\resources\images\icon.png" rel="icon"/>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <link href=".\resources\styles\main.css" rel="stylesheet" type="text/css">
        <link href=".\resources\styles\logout.css" rel="stylesheet" type="text/css">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="wrapper">
            <div class="content">
                <nav>
                    <ul class="navUl">
                        <li>
                            <a href="index.php">
                                <div class="icon">
                                    <i class="fa fa-home" aria-hidden="true"></i>
                                    <i class="fa fa-home" aria-hidden="true"></i>
                                </div>
                                <div class="name" data-test="Home"><b>Home</b></div>
                            </a>
                        </li>
                        <li>
                            <a href=".\register.php">
                                <div class="icon">
                                    <i class="fa fa-registered" aria-hidden="true"></i>
                                    <i class="fa fa-registered" aria-hidden="true"></i>
                                </div>
                                <div class="name" data-test="Register"><b>Register</b></div>
                            </a>
                        </li>
                        <li>
                            <a href=".\logout.php">
                                <div class="icon">
                                    <i class="fa fa-sign-out" aria-hidden="true"></i>
                                    <i class="fa fa-sign-out" aria-hidden="true"></i>
                                </div>
                                <div class="name" data-test="Logout"><b>Logout</b></div>
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="logout">
                    <input type="button" value="Logout" class="logout_button" onclick="location.href='.\\resources\\scripts\\logout.php'">
                </div>
            </div>
        </div>
    </body>
    </html>

<?php
}
else{
    header("Location: .\login.php");
}
?>