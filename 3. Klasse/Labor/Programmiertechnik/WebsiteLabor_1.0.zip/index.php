<!--
    Index.php
    Author: Valentin Adlgasser
    Date: 03.06.2020
    Version: 1.1
-->

<!doctype html>
<html>
<head>
    <title>VaporDrinks</title>
    <link href=".\resources\images\icon.png" rel="icon"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <link href=".\resources\styles\main.css" rel="stylesheet" type="text/css">
    <link href=".\resources\styles\index.css" rel="stylesheet" type="text/css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>

<div class="wrapper">
    <div class="content">
        <nav>
            <ul class="navUl">
                <li>
                    <a href="index.php">
                        <div class="icon">
                            <i class="fa fa-home" aria-hidden="true"></i>
                            <i class="fa fa-home" aria-hidden="true"></i>
                        </div>
                        <div class="name" data-test="Home"><b>Home</b></div>
                    </a>
                </li>
                <li>
                    <a href=".\register.php">
                        <div class="icon">
                            <i class="fa fa-registered" aria-hidden="true"></i>
                            <i class="fa fa-registered" aria-hidden="true"></i>
                        </div>
                        <div class="name" data-test="Register"><b>Register</b></div>
                    </a>
                </li>
                <li>
                    <a href=".\logout.php">
                        <div class="icon">
                            <i class="fa fa-sign-out" aria-hidden="true"></i>
                            <i class="fa fa-sign-out" aria-hidden="true"></i>
                        </div>
                        <div class="name" data-test="Logout"><b>Logout</b></div>
                    </a>
                </li>
            </ul>
        </nav>

        <h1>
            <img src=".\resources\images\icon.png">
            <p class="slogan">You got the ingredients, we've got the rest</p>
        </h1>

        <div class="section">
            <div class="test">
                <section>
                    <b class="question">You need a database of all cocktails out there?</b><br>
                    We got all of it.
                </section><br>
            </div>
            <div class="aside">
                <aside>
                    <b><a href="login.php">Click here to login</a></b><br>
                </aside><br>
            </div>
        </div>

        <div class="article">
            <article>
                <b>You want to help our Database to grow?</b><br>
                Just send a text to example@vapordrinks.com
            </article><br>
        </div>
    </div>

    <footer class="footer">
        Made by Valentin Adlgasser
    </footer>

</div>


</body>

</html>