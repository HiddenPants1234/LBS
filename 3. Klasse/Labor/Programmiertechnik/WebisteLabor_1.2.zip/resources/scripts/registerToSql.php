<?php
if(isset($_POST['submit'])) {
    $title = $_POST['title'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $birthday = $_POST['birthday'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $repeatPassword = password_hash($_POST['repeatPassword'], PASSWORD_BCRYPT);
    $street = $_POST['street'];
    $city = $_POST['city'];
    $zipCode = $_POST['zipCode'];
    $province = $_POST['province'];
    $telephone = $_POST['telephone'];

    $sqlServername = "localhost";
    $sqlUsername = "root";
    $sqlPassword = "Test";
    $sqlDbName = "Website";

    $conn = new mysqli($sqlServername, $sqlUsername, $sqlPassword, $sqlDbName);

    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO register(Title, FirstName, LastName, Birthday, Email, Password, Street, City, ZipCode, Province, Telephone)
        VALUES ('$title', '$firstName', '$lastName', '$birthday', '$email', '$password', '$street', '$city', $zipCode, '$province', $telephone)";

    echo $sql;

    if($conn->query($sql) === TRUE) {
        echo "New record created";
    }
    else{
        "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
    header('Location: ..\..\index.php');
}