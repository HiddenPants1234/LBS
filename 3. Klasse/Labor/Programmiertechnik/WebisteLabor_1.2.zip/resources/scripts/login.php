<?php
session_start();

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if(!strlen($email) || !strlen($password)){
        die('Please enter email and password!');
    }

    $success = false;

    $sqlServername = "localhost";
    $sqlUsername = "root";
    $sqlPassword = "Test";
    $sqlDbName = "Website";

    $conn = new mysqli($sqlServername, $sqlUsername, $sqlPassword, $sqlDbName);

    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT Email, Password FROM register WHERE Email = '$email'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    if($result->num_rows > 0){
        if(password_verify($password, $row["Password"])){
            $success = true;
        }
        else{
            echo "Password or Email incorrect";
        }
    }
    else{
        echo "Password or Email incorrect";
    }

    $conn->close();

    if($success){
        $_SESSION['user_id'] = $email;
        header('Location: ..\..\profile.php');
    }
    else{
        echo "Not working";
    }

