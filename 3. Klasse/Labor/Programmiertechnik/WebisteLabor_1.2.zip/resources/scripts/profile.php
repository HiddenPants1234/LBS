<?php
session_start();

if(isset($_POST['submit'])) {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $birthday = $_POST['birthday'];
    $street = $_POST['street'];
    $city = $_POST['city'];
    $zipCode = $_POST['zipCode'];
    $province = $_POST['province'];
    $telephone = $_POST['telephone'];

    $sqlServername = "localhost";
    $sqlUsername = "root";
    $sqlPassword = "Test";
    $sqlDbName = "Website";
    $sessionId = $_SESSION['user_id'];

    $conn = new mysqli($sqlServername, $sqlUsername, $sqlPassword, $sqlDbName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "UPDATE register SET FirstName = '$firstName', LastName = '$lastName', Birthday = '$birthday', Street = '$street', City = '$city', ZipCode = $zipCode, Province = '$province', Telephone = '$telephone' WHERE Email = '$sessionId'";
    if($conn->query($sql) === TRUE){
        echo "Yeeted";
    }
    else{
        echo "NOT Yeeted";
    }

    $image = addslashes(file_get_contents($_FILES['uploadFile']['tmp_name']));
    $sql = "INSERT INTO uploads(Email, Link) VALUES('$sessionId', '$image')";

    if($conn->query($sql) === TRUE){
        echo "Working";
    }

    $conn->close();

}