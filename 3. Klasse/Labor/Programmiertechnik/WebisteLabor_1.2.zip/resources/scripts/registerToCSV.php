<?php
    if(isset($_POST['submit'])){
        $title = $_POST['title'];
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        $birthday = $_POST['birthday'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $repeatPassword = password_hash($_POST['repeatPassword'], PASSWORD_BCRYPT);
        $street = $_POST['street'];
        $city = $_POST['city'];
        $zipCode = $_POST['zipCode'];
        $province = $_POST['province'];
        $telephone = $_POST['telephone'];

        $sqlServername = "localhost";
        $sqlUsername = "root";
        $sqlPassword = "Test";
        $sqlDbName = "Website";

        $conn = new mysqli($sqlServername, $sqlUsername, $sqlPassword, $sqlDbName);

        $file_open = fopen("..\..\UserCSV\UserCSV.csv", "a");
        $form_data = array(
            'title' => $title,
            'firstName' => $firstName,
            'lastName' => $lastName,
            'birthday' => $birthday,
            'email' => $email,
            'password' => $password,
            'repeatPassword' => $repeatPassword,
            'street' => $street,
            'city' => $city,
            'zipCode' => $zipCode,
            'province' => $province,
            'telephone' => $telephone
        );
        fputcsv($file_open, $form_data);

        $emailAndPassword_data = array(
            'email' => $email,
            'password' => $password
        );
        $emailAndPassword = fopen("..\..\UserCSV\EmailAndPassword.csv", "a");
        fputcsv($emailAndPassword, $emailAndPassword_data);

        /**$filepath = "..\..\Uploads\\";
        $path_parts = pathinfo($_FILES['uploadFile']['name']);
        $file_name = $path_parts['filename'].'_'.time().'.'.$path_parts['extension'];

        move_uploaded_file($_FILES['uploadFile']['tmp_name'], $filepath.$file_name);**/
    }