<!--
    profile.php
    Author: Valentin Adlgasser
    Date: 03.06.2020
    Version: 1.
-->
<?php

session_start();

if(isset($_SESSION['user_id'])){
    $sqlServername = "localhost";
    $sqlUsername = "root";
    $sqlPassword = "Test";
    $sqlDbName = "Website";

    $conn = new mysqli($sqlServername, $sqlUsername, $sqlPassword, $sqlDbName);

    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }

    $sessionId = $_SESSION['user_id'];
    $sql = "SELECT * FROM register WHERE Email = '$sessionId'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $sql2 = "SELECT * FROM uploads WHERE Email = '$sessionId'";
    $result2 = $conn->query($sql2);
    $row2 = mysqli_fetch_array($result2);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
    <link href=".\resources\images\icon.png" rel="icon"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <link href=".\resources\styles\main.css" rel="stylesheet" type="text/css">
    <link href=".\resources\styles\profile.css" rel="stylesheet" type="text/css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
<div class="wrapper">
    <div class="content">
        <nav>
            <ul class="navUl">
                <li>
                    <a href="index.php">
                        <div class="icon">
                            <i class="fa fa-home" aria-hidden="true"></i>
                            <i class="fa fa-home" aria-hidden="true"></i>
                        </div>
                        <div class="name" data-test="Home"><b>Home</b></div>
                    </a>
                </li>
                <li>
                    <a href=".\register.php">
                        <div class="icon">
                            <i class="fa fa-registered" aria-hidden="true"></i>
                            <i class="fa fa-registered" aria-hidden="true"></i>
                        </div>
                        <div class="name" data-test="Register"><b>Register</b></div>
                    </a>
                </li>
                <li>
                    <a href=".\profile.php">
                        <div class="icon">
                            <i class="fa fa-user" aria-hidden="true"></i>
                            <i class="fa fa-user" aria-hidden="true"></i>
                        </div>
                        <div class="name" data-test="Profile"><b>Profile</b></div>
                    </a>
                </li>
                <li>
                    <a href=".\logout.php">
                        <div class="icon">
                            <i class="fa fa-sign-out" aria-hidden="true"></i>
                            <i class="fa fa-sign-out" aria-hidden="true"></i>
                        </div>
                        <div class="name" data-test="Logout"><b>Logout</b></div>
                    </a>
                </li>
            </ul>
        </nav>
        <form id="Register" action=".\resources\scripts\profile.php" method="post" enctype="multipart/form-data">
            <div ID="upload">
                <label for="profilePicture">Profile Picture:</label>
                <?php echo '<img src="data:image/jpeg;base64,'.base64_encode($row2['Link']).'"/>' ?>
                <input type="file" name="uploadFile">
            </div>
            <!--<div ID="upload">
                 <label for="uploadFile">Upload a file:</label>
                 <input type="file" name="uploadFile">
             </div><br>-->
            <div ID="Konto">
                <label for="firstName">First Name: <?php echo $row["FirstName"]?></label>
                <input type="text" id="firstName" name="firstName" placeholder="Enter your first name" autofocus="1"><br>
                <label for="lastName">Last Name: <?php echo $row["LastName"]?></label>
                <input type="text" id="lastName" name="lastName" placeholder="Enter your last name"><br>
                <label for="birthday">Birthday: <?php echo $row["Birthday"]?></label>
                <input type="date" id="birthday" name="birthday" placeholder="Enter your birthday"><br>
            </div><br>

            <div ID="address">
                <label for="street">Street: <?php echo $row["Street"]?></label>
                <input type="text" id="street" name="street" placeholder="Enter your street"><br>
                <label for="city">City: <?php echo $row["City"]?></label>
                <input type="text" id="city" name="city" placeholder="Enter your city"><br>
                <label for="zipCode">Zip Code: <?php echo $row["ZipCode"]?></label>
                <input type="number" id="zipCode" name="zipCode" placeholder="Enter your Zip Code" pattern="[0-9]{4}"><br>
                <label for="province">Province: <?php echo $row["Province"]?></label>
                <select id="province" name="province">
                    <option value="Burgenland">Burgenland</option>
                    <option value="Kärnten">Kärnten</option>
                    <option value="Niederösterreich">Niederösterreich</option>
                    <option value="Oberösterreich">Oberösterreich</option>
                    <option value="Salzburg">Salzburg</option>
                    <option value="Steiermark">Steiermark</option>
                    <option value="Tirol">Tirol</option>
                    <option value="Vorarlberg">Vorarlberg</option>
                    <option value="Wien">Wien</option>
                </select><br>
                <label for="telephone">Telephone: <?php echo $row["Telephone"]?></label>
                <input type="tel" id="telephone" name="telephone" placeholder="Enter your telephone number">
            </div><br>

            <!--<div ID="upload">
                 <label for="uploadFile">Upload a file:</label>
                 <input type="file" name="uploadFile">
             </div><br>-->

            <input type="submit" value="Update" name="submit">
            <input type="reset" value="Reset">

        </form>
    </div>
</div>

<footer class="footer">
    Made by Valentin Adlgasser
</footer>

</body>
</html>
    <?php
    $conn->close();
}
else{
    header("Location: .\login.php");
}
?>