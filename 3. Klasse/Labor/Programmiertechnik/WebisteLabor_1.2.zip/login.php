<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href=".\resources\images\icon.png" rel="icon"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <link href=".\resources\styles\main.css" rel="stylesheet" type="text/css">
    <link href=".\resources\styles\login.css" rel="stylesheet" type="text/css">
</head>
<body>
    <h1>
        You need to login!
    </h1>
    <form action=".\resources\scripts\login.php" method="post" class="login">
        <input type="email" name="email" placeholder="Enter your email address"><br>
        <input type="password" name="password" placeholder="Enter your password"><br>
        <input type="submit" value="Submit">
    </form>
</body>

</html>
