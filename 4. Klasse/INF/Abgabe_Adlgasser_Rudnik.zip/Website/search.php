<!DOCTYPE html>
<html>
<head>
    <link href=".\resources\styles\terms.css" rel="stylesheet" type="text/css">
</head>
<body>
    <form name="search" action="resources\scripts\searchSql.php" method="post">
        <label for="name">Enter name: </label>
        <input type="text" id="name" name="name" placeholder="Enter name" autofocus><br>
        <input type="submit" value="Submit" name="submit">
    </form>
    <div class="aside">
        <aside>
            <b><a href="index.php">Back home</a></b>
        </aside>
    </div>
</body>
</html>