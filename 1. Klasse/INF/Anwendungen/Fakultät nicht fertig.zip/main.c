#include <stdio.h>

int main() {
    int Zahl = 0;

    printf("Zahl eingeben: ");
    scanf("%i", &Zahl);

    for (int Zahl = 0; Zahl < Zahl+1 ; ++Zahl) {
        printf()
    }

    return 0;
}