#include <stdio.h>
#include <math.h>
#include <stdlib.h>

double Umfang(int , int , int);
int Rechterwinkel(int, int, int);
double Flaeche(int, int, int);

struct dreieck{
    int a;
    int b;
    int c;
};

double Flaeche(int a, int b, int c){
    if(Rechterwinkel(a,b,c)==1) {
        return sqrt(((a + b + c) * (a + b - c) * (b + c - a) * (c + a - b)) / 4)/2;
    }
    if(Rechterwinkel(a,b,c)==0){
        int h = a+b+c;

        return ((h)/((h/2)*(h/(2-a))*(h/(2-b))*(h/(2-c))));
    }
}

int Rechterwinkel(int a, int b, int c){
    int helpa;
    int helpb;
    int helpc;

    helpa = a*a;
    helpb = b*b;
    helpc = c*c;

    if(a > b && a > c){
        if((helpc + helpb) == helpa){
            return(1);
        }
        else{
            return(0);
        }
    }
    if(b > a && b > c){
        if((helpc + helpa) == helpb){
            return(1);
        }
        else{
            return(0);
        }
    }
    if(c > b && c > a){
        if((helpa + helpb) == helpc){
            return(1);
        }
        else{
            return(0);
        }
    }
    else{
        return(0);
    }
}

double Umfang(int a, int b, int c){
    return a + b +c;
}

int main(int argc, char *argv[]) {
    struct dreieck seite;
    seite.a = atoi(argv[1]);
    seite.b = atoi(argv[2]);
    seite.c = atoi(argv[3]);


    printf("Umfang: %f\n",Umfang(seite.a, seite.b, seite.c));
    if(Rechterwinkel(seite.a, seite.b, seite.c) == 1){
        printf("Rechter-Winkel\n");
    }
    if(Rechterwinkel(seite.a, seite.b, seite.c) == 0){
        printf("Kein Rechter-Winkel\n");
    }
    printf("Flaeche: %f",Flaeche(seite.a, seite.b, seite.c));


    return 0;
}