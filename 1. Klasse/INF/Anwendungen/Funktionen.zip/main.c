#include <stdio.h>
int addieren(int summand1,int summand2) {
    return (summand1 + summand2);
}

int modulo(int zahl1, int zahl2){
    return(zahl1 % zahl2);
}

int vergleich(int zahl1, int zahl2){

    if(zahl1 < zahl2)
    {
        return (zahl2);
    }
    else if(zahl1 > zahl2)
    {
       return(zahl1);
    }
    else if (zahl1 == zahl2)
    {
      return(0);
    }

}

int main() {

    int aufgabe;
    int zahl1;
    int zahl2;
    int ergebniss;
    int differenz;
    int counter = 0;

    printf("Welche Aufgabe wollen Sie erledigen?\n");
    printf("Geben Sie 1 ein fuer: Eine Addition\n");
    printf("Geben Sie 2 ein fuer: Ein Modulo\n");
    printf("Geben Sie 3 ein fuer: Einen Vergleich\n");
    scanf("%i", &aufgabe);
    switch (aufgabe) {

        case 1:
            printf("Geben Sie den ersten Summanden ein: \n");
            scanf("%i", &zahl1);
            printf("Geben Sie den zweiten Summanden ein: \n");
            scanf("%i", &zahl2);
            ergebniss = addieren(zahl1, zahl2);
            printf("%i + %i = %i \n", zahl1, zahl2, ergebniss);

            break;

        case 2:
            printf("Geben Sie die erste Zahl ein: \n");
            scanf("%i",&zahl1);
            printf("Geben Sie die zweite Zahl ein:\n");
            scanf("%i",&zahl2);

            ergebniss = modulo(zahl1,zahl2);
            printf("%i Modulo %i = %i\n",zahl1,zahl2,ergebniss);

            break;

        case 3:
            printf("Geben Sie die erste Zahl ein: \n");
            scanf("%i",&zahl1);
            printf("Geben Sie die zweite Zahl ein:\n");
            scanf("%i",&zahl2);

            ergebniss = vergleich(zahl1,zahl2);

            if(zahl1<ergebniss)
            {
                differenz = ergebniss - zahl1;
                printf("Die groessere Zahl ist: %i\n",ergebniss);
                printf("Die Differenz betraegt: %i\n",differenz);
            }
            else if(zahl2<ergebniss)
            {
                differenz = ergebniss - zahl2;
                printf("Die groessere Zahl ist: %i\n",ergebniss);
                printf("Die Differenz betraegt: %i\n",differenz);
            }
            else if(ergebniss == 0)
            {
                printf("Ihre zwei eingegebenen Zahlen sind gleich gross\n");
            }

            break;

        default:
            printf("Bitte geben Sie eine gueltige Aufgabe ein\n");

            break;


    }

    printf("Zum Beenden 1 eingeben\n");
    scanf("%i", &counter);

    if (counter=1){
        return 0;
    }
}