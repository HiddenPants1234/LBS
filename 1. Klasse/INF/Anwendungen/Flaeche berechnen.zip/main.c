#include <stdio.h>

int main() {

    int laenge, breite, flaeche;
    int counter=0;

    printf("Laenge eingeben: ");
    scanf("%d", &laenge);

    printf("Breite eingeben: ");
    scanf("%d", &breite);

    flaeche = laenge * breite;
    printf("Flaeche = %d", flaeche);
    printf("\n");

    printf("Zum beenden 1 eingeben" );
    scanf("%i",&counter);

    if (counter = 1) {
        return 0;
    }
    }